// TODO:
// - Code cleanup
//	- system: .c .h
//  - dotstar: .c .h
// 	- button: .c .h
//  - encoder: .c .h
// - Implement UART
// - USB Device!

// C Standard libraries
#include <stdint.h>
#include <math.h>

// libopencm3 STM32
#include <libopencm3/stm32/rcc.h>
#include <libopencm3/stm32/gpio.h>
#include <libopencm3/stm32/spi.h>
#include <libopencm3/stm32/exti.h>
#include <libopencm3/stm32/syscfg.h>

// libopencm3 Cortex-M
#include <libopencm3/cm3/nvic.h>
#include <libopencm3/cm3/systick.h>

// Includes

// Defines
#define MATH_PI	3.1415

// Globals
volatile uint32_t system_ms;

uint32_t colours[8] = {	0x000000,
						0x0000FF,
						0x00FF00,
						0x00FFFF,
						0xFF0000,
						0xFF00FF,
						0xFFFF00,
						0xFFFFFF
						};


// Encoder reverse look up table
// CW:	00 -> 01 -> 11 -> 10 -> 00
// CCW:	00 -> 10 -> 11 -> 01 -> 00
int8_t encoder_direction[16] = {
			// Index   Last    Next    Increment   Direction
	0, 		// 0000    00      00      0           invalid
	1,		// 0001    00      01      1           CW			
	-1,		// 0010    00      10      -1          CCW			
	0,		// 0011    00      11      0           invalid
	-1,		// 0100    01      00      -1          CCW
	0,		// 0101    01      01      0           invalid
	0,		// 0110    01      10      0           invalid
	1,		// 0111    01      11      1           CW
	1,		// 1000    10      00      1           Cw
	0,		// 1001    10      01      0           invalid
	0,		// 1010    10      10      0           invalid
	-1,		// 1011    10      11      -1          CCW
	0,		// 1100    11      00      0           invalid
	-1,		// 1101    11      01      -1          CCW
	1,		// 1110    11      10      1           CW
	0,		// 1111    11      11      0           invalid
};

volatile uint8_t encoder_state;
volatile int8_t encoder_count;

volatile uint8_t colour_mode = 7;

// Called by systick interrupt 
void sys_tick_handler(void)
{
	system_ms++;
}

// Delay milliseconds
static void delay_ms(uint32_t delay)
{
	uint32_t return_ms = system_ms + delay;
	while (return_ms > system_ms);
}

// This function sets up the 1khz "system tick" count. The SYSTICK counter is a
// standard feature of the Cortex-M series.
static void systick_setup(void)
{
	// On reset the 16 MHz internal RC oscillator is selected as the default CPU clock.
	// clock rate / 1000 to get 1mS interrupt rate
	systick_set_reload(16000);
	systick_set_clocksource(STK_CSR_CLKSOURCE_AHB);
	systick_counter_enable();
	
	// Enable the interrupt
	systick_interrupt_enable();
}

// Configure the STM32 system clock
static void clock_setup(void)
{
//	rcc_clock_setup_pll(&rcc_hse_8mhz_3v3[RCC_CLOCK_3V3_168MHZ]);
}

static void gpio_setup(void)
{
	// Enable GPIOB clock
	rcc_periph_clock_enable(RCC_GPIOB);

	// Set PB14 to 'output push-pull'
	gpio_mode_setup(GPIOB, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, GPIO14);

}

static void button_setup(void)
{
	// Enable GPIOA clock.
	rcc_periph_clock_enable(RCC_GPIOC);
	rcc_periph_clock_enable(RCC_GPIOB);

	// Set up GPIO PC13 as 'input floating'
	gpio_mode_setup(GPIOC, GPIO_MODE_INPUT, GPIO_PUPD_NONE, GPIO13);

	// Set up GPIO PC6 as 'input floating'
	gpio_mode_setup(GPIOC, GPIO_MODE_INPUT, GPIO_PUPD_NONE, GPIO6);

	// Set up GPIO PC6 as 'input floating'
	gpio_mode_setup(GPIOB, GPIO_MODE_INPUT, GPIO_PUPD_NONE, GPIO13);

	// Set up GPIO PC6 as 'input floating'
	gpio_mode_setup(GPIOB, GPIO_MODE_INPUT, GPIO_PUPD_NONE, GPIO15);
}

// Configure SPI1
static void spi_init(void)
{
    /* Enable GPIOA clock. */
	rcc_periph_clock_enable(RCC_GPIOA);

	// Set pin mode for SPI managed pins to alternate function
	// // SCLK (PA5), MISO (PA6), MOSI (PA7)
    gpio_mode_setup(GPIOA, GPIO_MODE_AF, GPIO_PUPD_NONE, GPIO5 | GPIO6 | GPIO7);

    // Set alternate function for SPI managed pins to AF5 for SPI1
    gpio_set_af(GPIOA, GPIO_AF5, GPIO5 | GPIO6 | GPIO7);

    // Enable SPI periperal clock
    rcc_periph_clock_enable(RCC_SPI1);

    // Initialize SPI1 as master
    spi_init_master(
        SPI1,
        SPI_CR1_BAUDRATE_FPCLK_DIV_16,		// 16MHz DIV_16: 1MHz
        SPI_CR1_CPOL_CLK_TO_1_WHEN_IDLE,   	// CPOL: Clock high when idle
        SPI_CR1_CPHA_CLK_TRANSITION_2,     	// CPHA: Clock phase: read on rising edge of clock
        SPI_CR1_DFF_8BIT,
        SPI_CR1_MSBFIRST);

    spi_disable_crc(SPI1);

    // Have SPI peripheral manage NSS pin (pulled low when SPI enabled)
    // spi_enable_ss_output(SPI1);

    spi_enable(SPI1);
}

static void dotstar_set_hex(uint32_t* colour, uint8_t len)
{
	// Send the start of frame 32-bit zero
 	spi_send(SPI1, 0x0);
	spi_send(SPI1, 0x0);
	spi_send(SPI1, 0x0);
	spi_send(SPI1, 0x0);

	for(uint8_t i = 0; i < len; i++)
	{
		spi_send(SPI1, 0xFF);
		spi_send(SPI1, (colour[i] & 0xFF0000) >> 16);	// Red		(Datasheet is incorrect! (Blue, Green, Red))
		spi_send(SPI1, (colour[i] & 0x0000FF) >> 0);	// Blue
		spi_send(SPI1, (colour[i] & 0x00FF00) >> 8);	// Green
	}

	// Send end of Frame 32-bit all ones
	spi_send(SPI1, 0xFF);
	spi_send(SPI1, 0xFF);
	spi_send(SPI1, 0xFF);
	spi_send(SPI1, 0xFF);
}

static uint8_t dotstar_ramp(uint8_t angle)
{
	uint8_t amp = 0;
	if(angle < 128)
	{
		return 2*angle;
	}
	else
	{
		return 255 - (2*angle);
	}
}

static void dotstar_animation(uint32_t* leds, uint8_t len)
{
	static uint32_t angle = 0;

	if(angle >= 255)
		angle = 0;
	else
		angle += 5;
	
	leds[0] = (dotstar_ramp((angle + 32) % 255) << 16) | (dotstar_ramp((angle + 160) % 255));
	leds[1] = (dotstar_ramp((angle + 96) % 255) << 16) | (dotstar_ramp((angle + 224) % 255));
	leds[2] = (dotstar_ramp((angle + 160) % 255) << 16) | (dotstar_ramp((angle + 32) % 255));
	leds[3] = (dotstar_ramp((angle + 224) % 255) << 16) | (dotstar_ramp((angle + 96) % 255));
}

static void dotstar_set_colour(uint32_t* leds, uint8_t len, uint32_t colour)
{
	static uint32_t angle = 0;

	for(uint32_t i = 0; i < len; i++)
	{
		leds[i] = colour;
	}
}

// Enable GPIO and EXTI interrupts
// Available:
//	- NVIC_EXTI0_IRQ
//	- NVIC_EXTI1_IRQ
//	- NVIC_EXTI2_IRQ
//	- NVIC_EXTI3_IRQ
//	- NVIC_EXTI4_IRQ
// 	- NVIC_EXTI9_5_IRQ
// 	- NVIC_EXTI15_10_IRQ
static void exti_setup(void)
{
	// PD14, PD15
	rcc_periph_clock_enable(RCC_GPIOD);

	// Enable AFIO clock. (needed only for F1??)
	// rcc_periph_clock_enable(RCC_AFIO);
	rcc_periph_clock_enable(RCC_SYSCFG);

	// Enable EXTI interrupt
	nvic_enable_irq(NVIC_EXTI15_10_IRQ);
	nvic_enable_irq(NVIC_EXTI0_IRQ);

	// Set GPIO to 'input float'. */
	gpio_mode_setup(GPIOD, GPIO_MODE_INPUT, GPIO_PUPD_NONE, GPIO14);
	gpio_mode_setup(GPIOD, GPIO_MODE_INPUT, GPIO_PUPD_NONE, GPIO15);
	gpio_mode_setup(GPIOD, GPIO_MODE_INPUT, GPIO_PUPD_PULLDOWN, GPIO0);

	// Configure the EXTI subsystem.
	exti_select_source(EXTI14, GPIOD);
	exti_select_source(EXTI15, GPIOD);
	// SYSCFG_EXTICR4 |= 0b11 << 8;
	exti_select_source(EXTI0, GPIOD);

	exti_set_trigger(EXTI14, EXTI_TRIGGER_BOTH);
	exti_set_trigger(EXTI15, EXTI_TRIGGER_BOTH);
	exti_set_trigger(EXTI0, EXTI_TRIGGER_RISING);

	exti_enable_request(EXTI14);
	exti_enable_request(EXTI15);
	exti_enable_request(EXTI0);

	// Initialise encoder count and state
	encoder_state = ((GPIOD_IDR >> 14) & 0b11);
	encoder_count = 0;
}

void exti15_10_isr(void)
{
	static volatile uint8_t state;
	
	// Set the current state: last-state[4:3], next-state[2:0]
	//state = ((state << 2) | gpio_get(GPIOB, GPIO4) | (gpio_get(GPIOB, GPIO5) << 1)) & 0b1111;
	// cha = (GPIOD_IDR & BIT14) >> 14;	//gpio_get(GPIOD, GPIO14);
	// chb = (GPIOD_IDR & BIT15) >> 15;	//gpio_get(GPIOD, GPIO15);
	// state = ((state << 2) & 0b1100) | ((GPIOD_IDR >> 14) & 0b11);
	state = ((encoder_state << 2) & 0b1100) | ((GPIOD_IDR >> 14) & 0b11);
	
	if(encoder_direction[state] != 0)
	{
		encoder_state = state;
		// Increment/Decrement the encoder count
		encoder_count += encoder_direction[state];
		
		if(colour_mode + encoder_direction[state] < 0)
		{
			colour_mode = 7;
		}
		else if(colour_mode + encoder_direction[state] > 7)
		{
			colour_mode = 0;
		}
		else
		{
			colour_mode += encoder_direction[state];
		}
	}	

	// exti_disable_request(EXTI14);
	exti_reset_request(EXTI14);
	exti_reset_request(EXTI15);
}

void exti0_isr(void)
{
	exti_reset_request(EXTI0);
}

int main(void) {
	
	uint32_t leds[4];
	uint32_t colour;

	clock_setup();
	gpio_setup();
	button_setup();
	systick_setup();
	spi_init();
	exti_setup();

	while(1)
	{
		//Toggle the LED
		gpio_toggle(GPIOB, GPIO14);	

		// if(!gpio_get(GPIOB, GPIO13))	//PC13, PC6, PB13, PB15
		// {
		// 	if(colour_mode < 7)
		// 		colour_mode++;
		// 	else
		// 		colour_mode = 0;
			
		// 	colour = colours[colour_mode];
		// 	delay_ms(100);
		// }
		// else if(!gpio_get(GPIOB, GPIO15))	//PC13, PC6, PB13, PB15
		// {
		// 	if(colour_mode > 0)
		// 		colour_mode--;
		// 	else
		// 		colour_mode = 7;
			
			colour = colours[colour_mode];
		// 	delay_ms(100);
		// }

		if(!gpio_get(GPIOC, GPIO6))
		{
			dotstar_animation(leds, 4);
		}
		else
		{
			dotstar_set_colour(leds, 4, colour);
		}
		
		dotstar_set_hex(leds, 4);
		delay_ms(10);

	}
}
